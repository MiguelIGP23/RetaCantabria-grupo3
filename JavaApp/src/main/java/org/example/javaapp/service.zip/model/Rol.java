package org.example.javaapp.model;

public enum Rol {
    ADMINISTRADOR, DISEÑADOR, PROFESOR, ALUMNO
}
