package org.example.javaapp.service;

import org.example.javaapp.model.Ruta;

public interface IRutaService extends IService<Ruta, Integer>{

}
