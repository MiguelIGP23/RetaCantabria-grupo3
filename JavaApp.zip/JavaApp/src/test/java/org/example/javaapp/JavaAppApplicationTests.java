package org.example.javaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
