package org.example.javaapp.model;

public enum Clasificacion {
    CIRCULAR, LINEAL
}
