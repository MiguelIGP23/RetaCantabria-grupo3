package org.example.javaapp.repository;

import org.example.javaapp.model.PuntosInteres;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PuntosInteresRepository extends JpaRepository<PuntosInteres, Integer> {
}
