package org.example.javaapp.service;

import org.example.javaapp.model.Usuario;

public interface IServiceUsuario extends IService<Usuario, Integer>{
}
