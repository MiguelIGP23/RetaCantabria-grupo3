package org.example.javaapp.service;

import org.example.javaapp.model.Ruta;

public interface IServiceRuta extends IService<Ruta, Integer>{

}
