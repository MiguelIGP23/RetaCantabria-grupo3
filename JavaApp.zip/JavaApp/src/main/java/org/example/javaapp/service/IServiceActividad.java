package org.example.javaapp.service;

import org.example.javaapp.model.Actividad;

public interface IServiceActividad extends IService<Actividad, Integer> {
}
