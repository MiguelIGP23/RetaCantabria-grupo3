package org.example.javaapp.repository;

import org.example.javaapp.model.ImagenesInteres;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImagenInteresRepository extends JpaRepository<ImagenesInteres,Integer> {
}
