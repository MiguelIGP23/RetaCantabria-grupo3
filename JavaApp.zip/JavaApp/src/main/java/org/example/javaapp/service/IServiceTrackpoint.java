package org.example.javaapp.service;

import org.example.javaapp.model.Trackpoint;
import org.example.javaapp.model.TrackpointId;

public interface IServiceTrackpoint extends IService<Trackpoint, TrackpointId> {
}
