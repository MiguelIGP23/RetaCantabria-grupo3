package org.example.javaapp.service;

import org.example.javaapp.model.PuntosPeligro;

public interface IServicePuntosPeligro extends IService<PuntosPeligro, Integer> {
}
