package org.example.javaapp.service;

import org.example.javaapp.model.PuntosInteres;

public interface IServicePuntosInteres extends IService<PuntosInteres, Integer> {
}
