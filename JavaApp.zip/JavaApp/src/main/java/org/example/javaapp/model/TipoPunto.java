package org.example.javaapp.model;

public enum TipoPunto {
    HISTORICO, MIRADOR, AREA_DE_DESCANSO, PUNTO_DE_AGUA, ALOJAMIENTO, CULTURAL, GEOLOGICO, FAUNA, BOTANICO
}
