package org.example.javaapp.service;

import org.example.javaapp.model.ImagenesPeligro;

public interface IServiceImagenPeligro extends IService<ImagenesPeligro,Integer> {
}
