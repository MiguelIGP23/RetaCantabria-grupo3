package org.example.javaapp.service;

import org.example.javaapp.model.ImagenesInteres;

public interface IServiceImagenInteres extends IService<ImagenesInteres,Integer> {
}
