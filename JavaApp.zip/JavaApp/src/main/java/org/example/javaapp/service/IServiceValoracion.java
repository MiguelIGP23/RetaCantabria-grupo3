package org.example.javaapp.service;

import org.example.javaapp.model.Valoracion;

public interface IServiceValoracion extends IService<Valoracion, Integer>{

}
